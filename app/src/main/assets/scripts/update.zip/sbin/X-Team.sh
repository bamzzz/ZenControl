#!/sbin/sh
# sdcard Fix Permissions: Recovery Flashable Zip
# by X Anwar WJR @ X-Team

OUTFD=/proc/self/fd/$2;
ui_print() {
  echo -ne "ui_print $1\n" > $OUTFD;
  echo -ne "ui_print\n" > $OUTFD;
}
set_perm() {
  files=$(echo $* | awk '{ print substr($0, index($0,$4)) }');
  for i in $files; do
    chown $1.$2 $i; chown $1:$2 $i;
    chmod $3 $i;
  done;
}
set_perm_recursive() {
  dirs=$(echo $* | awk '{ print substr($0, index($0,$5)) }');
  for i in $dirs; do
    chown -R $1.$2 $i; chown -R $1:$2 $i;
    find "$i" -type d -exec chmod $3 {} +;
    find "$i" -type f -exec chmod $4 {} +;
  done;
}
show_progress() { echo "progress $1 $2" > $OUTFD; }
set_progress() { echo "set_progress $1" > $OUTFD; }
restore_con() { test -e /sbin/restorecon && restorecon -R $* || /system/bin/toolbox restorecon -R $*; }

ui_print " ";
ui_print "sdcard Fix Permissions Script";
ui_print " by X Anwar WJR @ X-Team ";
show_progress 1.34 0;

ui_print " ";
ui_print "Mounting...";
busybox mount /data;
busybox mount /system;
set_progress 0.2;

ui_print " ";
ui_print "Setting /data/media to media_rw and fixing...";
set_perm_recursive 1023 1023 0775 0664 "/data/media";
set_perm 1023 1023 0770 "/data/media" "/data/media/0" "/data/media/obb";
restore_con /data/media/0;
set_progress 0.6;

if [ -d /data/media/clockworkmod -o -d /data/media/0/clockworkmod ]; then
  ui_print " ";
  ui_print "Setting CWM directory perms...";
  set_perm_recursive 0 0 0777 0777 "/data/media/clockworkmod";
  set_perm_recursive 0 0 0777 0666 "/data/media/0/clockworkmod";
fi;
set_progress 0.7;

if [ -d /data/media/0/TWRP ]; then
  ui_print " ";
  ui_print "Setting TWRP directory perms...";
  set_perm_recursive 0 0 0777 0666 "/data/media/0/TWRP";
fi;
set_progress 0.8;

if [ -d /data/media/multirom -o -d /data/media/0/multirom ]; then
  ui_print " ";
  ui_print "Setting MultiROM directory perms...";
  set_perm_recursive 0 0 0755 0755 "/data/media/multirom" "/data/media/0/multirom";
  set_perm 0 0 0770 "/data/media/multirom" "/data/media/0/multirom";
  set_perm 1023 1023 0777 "/data/media/multirom/roms" "/data/media/0/multirom/roms";
  set_perm 1023 1023 0666 "/data/media/multirom/.nomedia" "/data/media/0/multirom/.nomedia";
  set_perm 0 0 0750 "/data/media/multirom/trampoline" "/data/media/0/multirom/trampoline";
  set_perm 0 0 0666 "/data/media/multirom/multirom.ini" "/data/media/0/multirom/multirom.ini";
  set_perm 0 0 0644 "/data/media/multirom/adbd" "/data/media/0/multirom/adbd" \
    "/data/media/multirom/mrom.fstab" "/data/media/0/multirom/mrom.fstab" \
    "/data/media/multirom/ubuntu-init/local" "/data/media/0/multirom/ubuntu-init/local" \
    "/data/media/multirom/ubuntu-touch-init/scripts/touch" "/data/media/0/multirom/ubuntu-touch-init/scripts/touch" \
    "/data/media/multirom/ubuntu-touch-sysimage-init/scripts/touch" "/data/media/0/multirom/ubuntu-touch-sysimage-init/scripts/touch";
  ui_print "Note: You will need to dirty flash your secondary ROMs to ensure their permissions are correct";
fi;
set_progress 1.1;

ui_print " ";
ui_print "Unmounting...";
umount /data;
umount /system;
set_progress 1.2;

ui_print " ";
ui_print "Done!";
set_progress 1.34;
exit 0;