#!/sbin/sh
/sbin/watchdogd &
#
#/sbin/su --daemon &
